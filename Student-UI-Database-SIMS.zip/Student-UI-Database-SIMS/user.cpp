#include "user.h"

User::User()
{
    ID="";
    FirstName="";
    LastName="";
}
User::getID()
{





}
