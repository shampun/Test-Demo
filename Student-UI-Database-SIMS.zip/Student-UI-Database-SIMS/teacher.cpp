#include "teacher.h"
#include "user.h"
#include <QString>

using namespace std;




Teacher::ADDGrade()
{

}
Teacher::ADDStudent()
{


}
Teacher::DELStudent()
{

}
Teacher::DELGrade()
{

}
Teacher::getID()
{
return ID;
}
Teacher::ViewClasses()
{

}
